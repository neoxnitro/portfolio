<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('deposits', function (Blueprint $table) {
            $table->id();
            $table->string('pay_method');
            $table->decimal('amount', 8, 2);
            $table->string('currency');
            $table->string('status')->default('pending');   // pending, processing, confirmed, error.
            $table->string('last_trx_id')->nullable();     // I don't know what kind of view the BI has, but this information could be useful (only for a human).
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('deposits');
    }
};
