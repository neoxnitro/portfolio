<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SuperWalletzController;

// webhook for superwalletz
Route::post('/superwalletz/{id}', [SuperWalletzController::class, 'callback'])->name('superwalletz.api');
