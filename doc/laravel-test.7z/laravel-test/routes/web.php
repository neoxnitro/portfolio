<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\SuperWalletzController;

// home
Route::get('/', function () {
    return view('welcome');
});

// deposit route
Route::post('/deposit', [PaymentController::class, 'store']);
// deposit status for superwalletz.status
Route::get('/superwalletz/{id}', [SuperWalletzController::class, 'status'])->name('superwalletz.status');

Route::get('/deposit', function () {
    return abort(404);
});
