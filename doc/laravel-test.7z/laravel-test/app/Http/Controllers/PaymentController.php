<?php

namespace App\Http\Controllers;

use App\Http\Controllers\EasyMoneyController;
use App\Http\Controllers\SuperWalletzController;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function store(Request $request)
    {
        $payMethod = $request->input('pay-method');

        // switch to the payment method
        if ($payMethod === 'easymoney') {
            $easyMoneyController = new EasyMoneyController();
            return $easyMoneyController->store($request);
        } elseif ($payMethod === 'superwalletz') {
            $superWalletzController = new SuperWalletzController();
            return $superWalletzController->store($request);
        } else {
            return redirect('/')->with('error', 'Invalid payment method');
        }
    }
}
