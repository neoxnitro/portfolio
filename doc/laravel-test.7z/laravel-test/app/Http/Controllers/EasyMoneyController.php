<?php

namespace App\Http\Controllers;

use App\Models\Deposit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Models\Transaction;

class EasyMoneyController extends Controller
{
    public function store(Request $request)
    {
        // sanity check + error messages
        $validated = $request->validate([
            'amount' => 'required|integer|min:1',
            'currency' => 'required|in:USD,EUR',
        ], [
            'amount.integer' => 'EasyMoney only accepts integer amounts (no decimals).',
            'amount.required' => 'The amount field is required.',
            'amount.min' => 'The amount must be at least 1.',
            'currency.required' => 'The currency field is required.',
            'currency.in' => 'The currency must be USD or EUR.',
        ]);

        // save the deposit
        $deposit = Deposit::create([
            'pay_method' => 'easymoney',
            'amount' => $validated['amount'],
            'currency' => $validated['currency'],
            'status' => 'pending',
        ]);

        // prepare the request
        $url = env('EASY_MONEY_API_URL');
        $requestData = [
            'amount' => (int)$validated['amount'],
            'currency' => $validated['currency']
        ];

        // save the transaction
        $transaction = Transaction::create([
            'deposit_id' => $deposit->id,
            'type' => 'request',
            'trx_id' => null, // no transaction id for easymoney
            'status' => 'pending',
            'details' => json_encode($requestData),
        ]);
        $deposit->last_trx_id = $transaction->id;
        $deposit->save();

        // handle the answer
        try {
            $response = Http::asJson()->post($url, $requestData);

            // save the transaction
            $transaction = Transaction::create([
                'deposit_id' => $deposit->id,
                'type' => 'response',
                'trx_id' => null,
                'status' => $response->body() === 'ok' ? 'success' : 'error',
                'details' => $response->body(),
            ]);
            $deposit->last_trx_id = $transaction->id;
            $deposit->save();

            if ($response->body() === 'ok') {
                $deposit->update(['status' => 'confirmed']);
                return redirect('/')->with('success', 'Deposit successful with EasyMoney!');
            } else {
                $deposit->update(['status' => 'error']);
                return redirect('/')->with('error', 'Payment failed with EasyMoney: ' . $response->body());
            }
        } catch (\Exception $e) {
            $deposit->update(['status' => 'error']);
            $transaction = Transaction::create([
                'deposit_id' => $deposit->id,
                'type' => 'error',
                'trx_id' => null,
                'status' => 'error',
                'details' => $e->getMessage(),
            ]);
            $deposit->last_trx_id = $transaction->id;
            $deposit->save();
            return redirect('/')->with('error', 'An error occurred: ' . $e->getMessage());
        }
    }
}
