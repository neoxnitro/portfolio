<?php

namespace App\Http\Controllers;

use App\Models\Deposit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Models\Transaction;

class SuperWalletzController extends Controller
{
    public function store(Request $request)
    {
        // sanity check + error messages
        $validated = $request->validate([
            'amount' => 'required|numeric|min:1',
            'currency' => 'required|in:USD,EUR',
        ], [
            'amount.required' => 'The amount field is required.',
            'amount.min' => 'The amount must be at least 1.',
            'currency.required' => 'The currency field is required.',
            'currency.in' => 'The currency must be USD or EUR.',
        ]);

        // save the deposit
        $deposit = Deposit::create([
            'pay_method' => 'superwalletz',
            'amount' => $validated['amount'],
            'currency' => $validated['currency'],
            'status' => 'processing',
        ]);

        // prepare the request
        $url = env('SUPERWALLETZ_API_URL');
        $requestData = [
            'amount' => $validated['amount'],
            'currency' => $validated['currency'],
            'callback_url' => route('superwalletz.api', $deposit->id),
        ];

        // save the transaction
        $transactionData = array_diff_key($requestData, ['callback_url' => '']);
        $transaction = Transaction::create([
            'deposit_id' => $deposit->id,
            'type' => 'request',
            'trx_id' => null,
            'status' => 'pending',
            'details' => json_encode($transactionData),
        ]);
        $deposit->last_trx_id = $transaction->id;
        $deposit->save();

        // handle the answer
        try {
            $response = Http::asJson()->post($url, $requestData);
            $responseData = $response->json();
            $transactionId = $responseData['transaction_id'] ?? null;

            // save the transaction
            $transaction = Transaction::create([
                'deposit_id' => $deposit->id,
                'type' => 'response',
                'trx_id' => $transactionId,
                'status' => $transactionId ? 'success' : 'error',
                'details' => $response->body(),
            ]);
            $deposit->last_trx_id = $transaction->id;
            $deposit->save();

            if ($transactionId && strpos($transactionId, 'trx_') === 0) {
                $deposit->update([
                    'request_transaction_id' => $transactionId
                ]);

                // There are more elegant solutions than this, it's a workaround for testing!
                return redirect('/')->with([
                    'success' => 'Deposit initiated with SuperWalletz! Transaction ID: ' . $transactionId,
                    'status_link' => route('superwalletz.status', $deposit->id),
                ]);
            } else {
                $deposit->update(['status' => 'error']);
                return redirect('/')->with('error', 'Payment failed with SuperWalletz: Invalid transaction ID');
            }
        } catch (\Exception $e) {
            $deposit->update(['status' => 'error']);
            $transaction = Transaction::create([
                'deposit_id' => $deposit->id,
                'type' => 'error',
                'trx_id' => null,
                'status' => 'error',
                'details' => $e->getMessage(),
            ]);
            $deposit->last_trx_id = $transaction->id;
            $deposit->save();
            return redirect('/')->with('error', 'An error occurred: ' . $e->getMessage());
        }
    }

    public function callback(Request $request, $id)
    {
        // If the deposit does not exist, return an error ...
        // Due to the foreign key constraint,
        // we cannot create a transaction without having a deposit.
        try {
            $deposit = Deposit::findOrFail($id);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['error' => 'Deposit not found'], 404);
        }

        // retrive callback data
        $callbackData = $request->all();
        $callbackTransactionId = $callbackData['transaction_id'] ?? null;
        $callbackStatus = $callbackData['status'] ?? null;

        // save the transaction
        $transaction = Transaction::create([
            'deposit_id' => $deposit->id,
            'type' => 'webhook',
            'trx_id' => $callbackTransactionId,
            'status' => $callbackStatus ?? 'error',
            'details' => json_encode($callbackData),
        ]);
        $deposit->last_trx_id = $transaction->id;
        $deposit->save();

        // The statement does not specify whether the API server expects a response or not, so to be safe ...
        if ($callbackTransactionId && $callbackStatus) {
            $deposit->update([
                'status' => $callbackStatus === 'success' ? 'confirmed' : 'failed',
                'confirmation_transaction_id' => $callbackTransactionId
            ]);
            return response()->json(['message' => 'Payment confirmed for deposit ' . $id]);
        } else {
            return response()->json(['error' => 'Invalid callback data'], 400);
        }
    }

    public function status($id)
    {
        $deposit = Deposit::findOrFail($id);
        // it's dirty, but it's just for the sake of the example
        return 'Deposit status: ' . $deposit->status;
    }
}
