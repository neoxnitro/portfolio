<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Deposit extends Model
{
    protected $fillable = ['pay_method', 'amount', 'currency', 'status', 'last_trx_id'];
}
