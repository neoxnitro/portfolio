<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    protected $fillable = ['deposit_id', 'trx_id', 'type', 'details'];

    public function deposit()
    {
        return $this->belongsTo(Deposit::class);
    }
}
